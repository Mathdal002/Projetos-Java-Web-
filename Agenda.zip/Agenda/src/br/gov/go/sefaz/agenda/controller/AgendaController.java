// ***  AgendaController = Controller ***
package br.gov.go.sefaz.agenda.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.gov.go.sefaz.agenda.dao.AgendaDao;
import br.gov.go.sefaz.agenda.model.Contato;

@WebServlet(urlPatterns = { "/controller", "/main", "/insert", "/select" })
public class AgendaController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private AgendaDao agendaDao;
	private Contato contato;

	public AgendaController() {
		super();
		agendaDao = new AgendaDao();
		contato = new Contato();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath()).append("\n");
		String action = request.getServletPath();
		System.out.println(action);
		if (action.equals("/main")) {
			listarContatos(request, response);
		} else if (action.equals("/insert")) {
			novoContato(request, response);
		} else if (action.equals("/select")) {
			listarContato(request, response);
		} else {
			response.sendRedirect("index.html");
		}
	}

	// Listar contatos
	protected void listarContatos(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Criando um objeto que ir� receber os dados Contato(JavaBeans)
		ArrayList<Contato> lista = (ArrayList<Contato>) agendaDao.listarContatos();
		// Encaminhar a lista ao documento agenda.jsp
		request.setAttribute("contatos", lista);
		RequestDispatcher requestdispatcher = request.getRequestDispatcher("agenda.jsp");
		requestdispatcher.forward(request, response);
	}

	// Novo contato
	protected void novoContato(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// setar as vari�veis Contato(javaBeans)
		contato.setNome(request.getParameter("nome"));
		contato.setFone(request.getParameter("fone"));
		contato.setEmail(request.getParameter("email"));
		// invocar o m�todo inserirContatos passando o objeto contato
		agendaDao.inserirContato(contato);
		// redirecionar para o documento agenda.jsp
		response.sendRedirect("main");
	}
	
	
	// Editar Contato
	protected void listarContato(HttpServletRequest request , HttpServletResponse response) {
		// Recebimento do id do contato que sera editado
		String idcon = request.getParameter("idcon");
		// Setar a vari�vel Contato(JavaBeans)
		contato.setIdcon(idcon);
	}

}
