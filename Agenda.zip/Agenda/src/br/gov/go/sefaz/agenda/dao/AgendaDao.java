// *** *AgendaDao = Dao ***
package br.gov.go.sefaz.agenda.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.gov.go.sefaz.agenda.model.Contato;

public class AgendaDao {

	// M�dulo de conex�o
	// Par�metros de conex�o
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://127.0.0.1:3306/estudos?useTimezone=true&serverTimezone=UTC";
	private String user = "root";
	private String password = "root";

	// M�todo de conex�o
	private Connection conectar() {
		Connection connection = null;
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
			return connection;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	/** CRUD CREATE **/
	public void inserirContato(Contato contato) {
		String sqlInsertContato = "insert into contatos(nome,fone,email) values(?,?,?)";
		// Objetos de conex�o com o banco de dados
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			// abrir a conex�o
			connection = conectar();
			// preparar a query para execu��o no banco de dados
			preparedStatement = connection.prepareStatement(sqlInsertContato);
			// Substituir os par�metros(?)pelo conte�do das vari�veis Contato(JavaBeans)
			preparedStatement.setString(1, contato.getNome());
			preparedStatement.setString(2, contato.getFone());
			preparedStatement.setString(3, contato.getEmail());
			// Executa a query
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				// Fecha o ResultSet
				rs.close();
				// Fecha o PreparedStatement
				if(preparedStatement != null) {
					preparedStatement.close();
				}
				// Fecha a conex�o com o banco de dados
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/** CRUD READ **/
	public List<Contato> listarContatos() {
		ArrayList<Contato> contatos = null;
		String sqlSelectContatos = "select * from contatos order by nome";
		// Objetos de conex�o com o banco de dados
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		// Criando um objeto para acessar a classe Contato(JavaBeans)
		try {
			connection = conectar();
			preparedStatement = connection.prepareStatement(sqlSelectContatos);
			rs = preparedStatement.executeQuery();
			contatos = new ArrayList<>();
			// o la�o abaixo ser� executado enquanto houver contatos
			while (rs.next()) {
				// variaveis de apoio que recebem os dados do banco
				String idcon = rs.getString(1);
				String nome = rs.getString(2);
				String fone = rs.getString(3);
				String email = rs.getString(4);
				// populando o ArrayList
				contatos.add(new Contato(idcon, nome, fone, email));
			}
			return contatos;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		} finally {
			try {
				// Fecha o ResultSet
				if(rs != null) {
					rs.close();
				}
				// Fecha o PreparedStatement
				if(preparedStatement != null) {
					preparedStatement.close();
				}
				// Fecha a conex�o com o banco de dados
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}